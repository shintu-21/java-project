package uk.tw.energy.controller;

import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import uk.tw.energy.domain.PricePlan;
import uk.tw.energy.service.CostService;

@RestController
@RequestMapping("/costs")
public class CostController {
	
	@Autowired
	CostService costService;
	
	@GetMapping("/last-week/{smartMeterId}/{energyPlan}")
    public ResponseEntity getLastWeekCost(@PathVariable String smartMeterId , PricePlan energyPlan) {
	   if (smartMeterId==null || energyPlan==null){
		   return new ResponseEntity<>("Smart Meter ID and a valid Price Plan should be present",HttpStatus.BAD_REQUEST);
	   }
       BigDecimal  cost = costService.getWeeklyCosts(smartMeterId,energyPlan);
        return ResponseEntity.ok(cost);
                
    }

}
