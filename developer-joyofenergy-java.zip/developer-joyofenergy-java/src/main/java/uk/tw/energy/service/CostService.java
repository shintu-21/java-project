package uk.tw.energy.service;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import uk.tw.energy.domain.ElectricityReading;
import uk.tw.energy.domain.PricePlan;

@Service
public class CostService {
	
	@Autowired
	MeterReadingService meterReadingService ;
	
	@Autowired
	PricePlanService pricePlanService ;
	
	 public BigDecimal getWeeklyCosts( String smartMeterId,PricePlan energyPlan) {
		 Optional<List<ElectricityReading>> electricityReadings = meterReadingService.getReadings(smartMeterId);
		 
		 List<ElectricityReading> filteredReadings = getFilteredReadings(electricityReadings.get());
		 BigDecimal cost=pricePlanService.calculateCost(filteredReadings,energyPlan);
		 
		 return cost;
	    }
	 
	 public List<ElectricityReading> getFilteredReadings(List<ElectricityReading> electricityReadings) {
	         return electricityReadings.stream()
	                .filter(electricityReading -> electricityReading.getTime().isAfter(Instant.now().minus(7,ChronoUnit.DAYS)))
	                .collect(Collectors.toList());              
	                
	    }

}
